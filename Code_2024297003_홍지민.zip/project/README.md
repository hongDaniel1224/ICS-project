# MIMO Channel Estimation Code Execution Guide

## 1. Project Overview

This project provides code for comparing deep learning-based channel estimation performance in a time-varying MIMO wireless channel environment. MATLAB is used to generate MIMO channel data, while Python is used to train and run inference with DNN-, CNN-, and LSTM-based models. The NMSE performance of each architecture is then compared.

This submission is not an exact, untouched clone of the original open-source repository. Instead, it is organized around the key MATLAB and Python scripts that were used or modified to solve the target problem of **time-varying MIMO channel estimation**.

---

## 2. Application Focus

The main objective of this submission is to predict intermediate channel values in a time-varying MIMO channel using pilot symbols. In particular, this project applies DNN, CNN, and LSTM-based models to the same channel estimation problem and compares their NMSE performance under different SNR values.

The main files highlighted in this project are listed below.

| File | Description |
|---|---|
| `README.md` | Documentation file that provides step-by-step instructions for environment setup and code execution. |
| `requirements.txt` | List of Python packages required to run the Python scripts. |
| `data` | Directory for storing generated training/inference input-output data, trained models, and prediction results. |
| `matlab/nn_channel_estimation.m` | Main MATLAB execution file. It performs MIMO channel generation, training/inference data generation, Python model execution, NMSE calculation, and result plotting. |
| `matlab/time_varying_channel_generation_MIMO.m` | MATLAB function for generating time-varying MIMO channel data. |
| `matlab/lte_system_configuration.m` | MATLAB function for setting the LTE/MIMO system configuration parameters used in the simulation. |
| `matlab/conv_data_complex2real.m` | MATLAB function for converting complex-valued channel data into real-valued data for neural network input/output processing. |
| `matlab/conv_data_real2complex.m` | MATLAB function for converting real-valued neural network output data back into complex-valued channel data. |
| `nn/dnn.py` | Python script for training and inference using the DNN-based channel estimation model. |
| `nn/cnn.py` | Python script for training and inference using the CNN-based channel estimation model. |
| `nn/lstm.py` | Python script for training and inference using the LSTM separation model, where a separate LSTM model is trained for each transmit antenna. |

---

## 3. Project Folder Structure

After extracting the compressed file, the project should be organized as follows.

```text
project/
├── README.md
├── requirements.txt
├── data
├── matlab/
│   ├── conv_data_complex2real.m
│   ├── conv_data_real2complex.m
│   ├── lte_system_configuration.m
│   ├── time_varying_channel_generation_MIMO.m
│   └── nn_channel_estimation.m
└── nn/
    ├── dnn.py
    ├── cnn.py
    └── lstm.py
```

Set the `project/` folder as the current working folder in MATLAB before running the code.

---

## 4. Recommended Execution Environment

This code uses both MATLAB and Python.

```text
OS      : Windows 10 or Windows 11 recommended
MATLAB  : R2021a or later recommended
Python  : Python 3.10 recommended
```

The Python scripts mainly use the following packages.

```text
numpy
pandas
tensorflow.keras
```

TensorFlow version compatibility is the reason why Python 3.10 is recommended.

---

## 5. Python Environment Setup

### Step 1. Check Python Installation

Open Command Prompt or a terminal and run the following command.

```bash
python --version
```

If Python is installed correctly, the output should look similar to the following.

```text
Python 3.10.x
```

If Python is not installed, install Python 3.10 first.

---

### Step 2. Move to the Project Folder

After extracting the compressed file, move to the project folder.

For example, if the project folder is located on the Desktop, run:

```bash
cd C:\Users\User\Desktop\project
```

You must modify the path according to the actual location of the project folder on your PC.

---

### Step 3. Create a Python Virtual Environment

Run the following command inside the project folder.

```bash
python -m venv venv
```

This command creates a virtual environment folder named `venv` inside the project folder.

---

### Step 4. Activate the Python Virtual Environment

On Windows, run:

```bash
venv\Scripts\activate
```

If the virtual environment is activated correctly, `(venv)` will appear at the beginning of the command line.

Example:

```text
(venv) C:\Users\User\Desktop\project>
```

---

### Step 5. Install the Required Python Packages

Install the required packages using the following command.

```bash
pip install -r requirements.txt
```

The `requirements.txt` file should include the following packages.

```text
numpy>=1.23,<2.0
pandas>=1.5
tensorflow==2.15.1
```

After installation, you can check whether TensorFlow was installed correctly by running:

```bash
python -c "import tensorflow as tf; print(tf.__version__)"
```

If the installation was successful, the TensorFlow version will be printed.

---

## 6. Checks Before Running MATLAB

### Step 1. Set the MATLAB Working Folder

Open MATLAB and set the current working folder to the `project/` folder.

The MATLAB Current Folder window should contain the following files and folders.

```text
README.md
requirements.txt
data
matlab/
nn/
```

---

### Step 2. Add the MATLAB Folder to the MATLAB Path

Because the main MATLAB script and related MATLAB functions are located in the `matlab/` folder, add this folder to the MATLAB path before running the code.

Run the following command in the MATLAB Command Window.

```matlab
addpath(genpath('matlab'))
```

---

### Step 3. Modify the Python Path in the MATLAB Code

The MATLAB main file may contain a Python executable path written for a specific personal computer.

For example, the code may include a path such as:

```matlab
C:\Users\hjm88\AppData\Local\Programs\Python\Python310\python.exe
```

This path may not work on another PC. Therefore, it must be changed to the Python executable path on your own PC.

After activating the virtual environment, you can check your Python path with the following command.

```bash
where python
```

For example, if the output is:

```text
C:\Users\User\Desktop\project\venv\Scripts\python.exe
```

replace the Python path inside `matlab/nn_channel_estimation.m` with this path.

---

### Step 4. Check Required MATLAB Files

The MATLAB main file uses the following MATLAB files.

```text
matlab/lte_system_configuration.m
matlab/time_varying_channel_generation_MIMO.m
matlab/conv_data_complex2real.m
matlab/conv_data_real2complex.m
```

If these files are not included in the `matlab/` folder or are not added to the MATLAB path, an execution error may occur.

---

## 7. How to Run the MATLAB Code

After completing the Python environment setup and MATLAB path configuration, run the following commands in the MATLAB Command Window.

```matlab
addpath(genpath('matlab'))
run('matlab/nn_channel_estimation.m')
```

Alternatively, open the `matlab/nn_channel_estimation.m` file in the MATLAB Editor and click the **Run** button.

The MATLAB code runs in the following order.

1. Set the MIMO system parameters.
2. Generate time-varying MIMO channel data.
3. Generate training CSV files.
4. Call the Python DNN, CNN, and LSTM models for training.
5. Generate inference channel data.
6. Predict the channel using the trained models.
7. Calculate the NMSE values of DNN, CNN, LSTM, and linear interpolation.
8. Plot the NMSE performance according to SNR.

---

## 8. Generated Data and Result Files

When the code is executed, a new result folder is created under the `data` folder based on the execution time.

Example:

```text
project/
├── data/
│   └── 260611153000/
│       ├── training_SNR20dB/
│       │   ├── input_data.csv
│       │   ├── output_data.csv
│       │   ├── input_data_LSTM_1.csv
│       │   ├── input_data_LSTM_2.csv
│       │   ├── ...
│       │   ├── input_data_LSTM_Nt.csv
│       │   ├── output_data_LSTM_1.csv
│       │   ├── output_data_LSTM_2.csv
│       │   ├── ...
│       │   ├── output_data_LSTM_Nt.csv
│       │   ├── dnn_model.h5
│       │   ├── cnn_model.h5
│       │   ├── lstm_model_1.h5
│       │   ├── lstm_model_2.h5
│       │   ├── ...
│       │   ├── lstm_model_Nt.h5
│       │   ├── predicted_data_dnn.csv
│       │   ├── predicted_data_cnn.csv
│       │   ├── predicted_data_lstm_1.csv
│       │   ├── predicted_data_lstm_2.csv
│       │   ├── ...
│       │   └── predicted_data_lstm_Nt.csv
│       └── inference_SNR0dB/
│           ├── input_data.csv
│           ├── input_data_LSTM_1.csv
│           ├── input_data_LSTM_2.csv
│           ├── ...
│           ├── input_data_LSTM_Nt.csv
│           ├── predicted_data_dnn.csv
│           ├── predicted_data_cnn.csv
│           ├── predicted_data_lstm_1.csv
│           ├── predicted_data_lstm_2.csv
│           ├── ...
│           └── predicted_data_lstm_Nt.csv
```

The LSTM-related input, output, model, and prediction files are generated separately for each transmit antenna. Therefore, if the number of transmit antennas is `Nt`, the files are generated from index `1` to `Nt`. For example, when `Nt = 8`, files such as `input_data_LSTM_1.csv` to `input_data_LSTM_8.csv`, `lstm_model_1.h5` to `lstm_model_8.h5`, and `predicted_data_lstm_1.csv` to `predicted_data_lstm_8.csv` are created.

The actual folder name may vary depending on the execution time and SNR setting.

---

## 9. How to Run the Python Scripts Separately

The default execution method is to run the Python scripts automatically through the MATLAB main file. However, if the CSV data has already been generated, each Python file can also be executed separately.

### DNN Training

```bash
python nn/dnn.py <data_dir> train <pilot_group> <Nt> <Nr> <Dt>
```

Example:

```bash
python nn/dnn.py data/training_SNR20dB train 10 8 8 20
```

### DNN Inference

```bash
python nn/dnn.py <data_dir> infer <pilot_group> <Nt> <Nr> <Dt> <model_path>
```

Example:

```bash
python nn/dnn.py data/inference_SNR0dB infer 10 8 8 20 data/training_SNR20dB/dnn_model.h5
```

### CNN Training

```bash
python nn/cnn.py <data_dir> train <pilot_group> <Nt> <Nr> <Dt>
```

Example:

```bash
python nn/cnn.py data/training_SNR20dB train 10 8 8 20
```

### CNN Inference

```bash
python nn/cnn.py <data_dir> infer <pilot_group> <Nt> <Nr> <Dt> <model_path>
```

Example:

```bash
python nn/cnn.py data/inference_SNR0dB infer 10 8 8 20 data/training_SNR20dB/cnn_model.h5
```

### LSTM Training

The `lstm.py` script trains a separate LSTM model for each transmit antenna index.

```bash
python nn/lstm.py <data_dir> train <pilot_group> <tx_i> <Nr>
```

Example:

```bash
python nn/lstm.py data/training_SNR20dB train 10 1 8
```

Here, `tx_i` is the transmit antenna index. For example, if `Nt = 8`, run the script separately for `tx_i = 1` to `tx_i = 8`.

### LSTM Inference

```bash
python nn/lstm.py <data_dir> infer <pilot_group> <tx_i> <Nr> <model_path>
```

Example:

```bash
python nn/lstm.py data/inference_SNR0dB infer 10 1 8 data/training_SNR20dB/lstm_model_1.h5
```

---

## 10. Main Parameter Description

The main parameters used in the MATLAB main file are listed below.

| Variable | Meaning | Current Value |
|---|---|---|
| `Nt` | Number of transmit antennas | `8` |
| `Nr` | Number of receive antennas | `8` |
| `Dt` | Pilot interval | `20` |
| `pilot_group` | Number of pilot groups used as input | `10` |
| `pilot_group_total` | Total number of pilot groups | `65` |
| `num_sample_training` | Number of training samples | `10000` |
| `num_sample_inference` | Number of inference samples | `1000` |
| `set_SNRdB` | Inference SNR range | `0:5:20` |
| `SNRdB` | Training SNR | `20` |

For the first test run, it is recommended to reduce the number of samples because full training may take a long time.

```matlab
num_sample_training = 100;
num_sample_inference = 10;
```

After confirming that the code runs correctly, change these values back to the original settings and run the full experiment.

---

## 11. Checking the Execution Results

If the code runs correctly, the following results will be generated.

### 1. Trained Model Files

```text
dnn_model.h5
cnn_model.h5
lstm_model_1.h5
lstm_model_2.h5
...
lstm_model_Nt.h5
```

### 2. Prediction Result CSV Files

```text
predicted_data_dnn.csv
predicted_data_cnn.csv
predicted_data_lstm_1.csv
predicted_data_lstm_2.csv
...
predicted_data_lstm_Nt.csv
```

### 3. NMSE Performance Plot

The plot compares the NMSE performance of the following methods.

```text
DNN
CNN
LSTM
Linear interpolation
```

---

## 12. Notes

1. The Python executable path inside the MATLAB code must be modified according to your own PC environment.
2. The MATLAB files in the `matlab/` folder must be added to the MATLAB path before running the code.
3. Python 3.10 is recommended for TensorFlow compatibility.
4. The full experiment may take a long time because the number of training samples is large.
5. For the first execution test, reduce `num_sample_training` and `num_sample_inference`.
6. Since MATLAB calls Python scripts, both the MATLAB environment and the Python environment must be configured correctly.
7. The Python models are saved in `.h5` format.

---

## 13. Full Execution Summary

A first-time user can follow the steps below.

```text
1. Extract the compressed file.
2. Install Python 3.10.
3. Move to the project folder.
4. Create a virtual environment using python -m venv venv.
5. Activate the virtual environment using venv\Scripts\activate.
6. Install the required packages using pip install -r requirements.txt.
7. Modify the Python path inside matlab/nn_channel_estimation.m according to your own PC.
8. Add the matlab folder to the MATLAB path using addpath(genpath('matlab')).
9. Run matlab/nn_channel_estimation.m in MATLAB.
10. Check the generated data folder, model files, prediction CSV files, and NMSE plot.
```

The main execution file of this project is `matlab/nn_channel_estimation.m`, and the main Python model files are `nn/dnn.py`, `nn/cnn.py`, and `nn/lstm.py`.
