function [cir, cfr] = time_varying_channel_generation_MIMO(sys_cfg, NR, NT, T, rho)
%TIME_VARYING_CHANNEL_GENERATION_MIMO Generate time-varying MIMO channels.
%
%   [cir, cfr] = TIME_VARYING_CHANNEL_GENERATION_MIMO(sys_cfg, NR, NT, T, rho)
%   generates channel impulse responses (CIRs) and channel frequency
%   responses (CFRs) for an NR-by-NT MIMO channel over T time instants.
%
%   Inputs:
%       sys_cfg - system configuration structure
%       NR      - number of receive antennas
%       NT      - number of transmit antennas
%       T       - number of time samples
%       rho     - spatial correlation parameter placeholder
%
%   Outputs:
%       cir     - channel impulse response, size [NR, NT, fft_size, T]
%       cfr     - channel frequency response, size [NR, NT, fft_size, T]
%
%   Note:
%       The current implementation uses independent Rayleigh fading
%       channels for each transmit-receive antenna pair. The input rho is
%       kept as a placeholder for future spatial correlation extensions.

carrier_freq = 2e9;  % Center frequency in Hz
max_doppler_freq = sys_cfg.user_speed * carrier_freq / 3e8;

%% Create a dummy channel object to obtain the channel filter delay
chan_dummy = comm.RayleighChannel( ...
    "SampleRate", sys_cfg.sample_rate, ...
    "MaximumDopplerShift", max_doppler_freq, ...
    "PathDelays", sys_cfg.tau, ...
    "AveragePathGains", sys_cfg.pdb, ...
    "NormalizePathGains", true);

filter_delay = info(chan_dummy).ChannelFilterDelay;

%% Create independent Rayleigh channel objects for each antenna pair
set_chan = cell(NR, NT);
for nr = 1:NR
    for nt = 1:NT
        set_chan{nr, nt} = comm.RayleighChannel( ...
            "SampleRate", sys_cfg.sample_rate, ...
            "MaximumDopplerShift", max_doppler_freq, ...
            "PathDelays", sys_cfg.tau, ...
            "AveragePathGains", sys_cfg.pdb, ...
            "NormalizePathGains", true);
    end
end

%% Generate time-domain and frequency-domain channel responses
channel_length = sys_cfg.fft_size + filter_delay;
cir = zeros(NR, NT, sys_cfg.fft_size, T);
cfr = zeros(NR, NT, sys_cfg.fft_size, T);

for nr = 1:NR
    for nt = 1:NT
        for tt = 1:T
            impulse_input = [1; zeros(channel_length - 1, 1)];
            cir_tmp = set_chan{nr, nt}(impulse_input);

            cir(nr, nt, :, tt) = cir_tmp(1:sys_cfg.fft_size);
            cfr(nr, nt, :, tt) = fft(squeeze(cir(nr, nt, :, tt)), sys_cfg.fft_size);
        end
    end
end

end
