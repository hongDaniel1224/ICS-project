function data = conv_data_real2complex(data)
%CONV_DATA_REAL2COMPLEX Convert real-valued data back into complex data.
%
%   data = CONV_DATA_REAL2COMPLEX(data) converts an input matrix of size
%   [num_sample, data_dim] into a complex-valued matrix of size
%   [num_sample, data_dim/2].
%
%   For each row vector v, the output row is defined as:
%       v(1:data_dim/2) + 1i*v(data_dim/2+1:end)
%
%   This function is used to reconstruct complex-valued channel estimates
%   from neural network prediction results.

data_dim = size(data, 2);

if mod(data_dim, 2) ~= 0
    error('The number of columns in the real-valued data must be even.');
end

data = data(:, 1:data_dim/2) + 1i * data(:, data_dim/2 + 1:end);

end
