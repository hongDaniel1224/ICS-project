clear;
clc;

%% System configuration
% This script compares DNN-, CNN-, and LSTM-based channel estimation
% performance in a time-varying MIMO channel.

sys_cfg.bandwidth = '10MHz';
sys_cfg.channel_model = 'vehB';
sys_cfg = lte_system_configuration(sys_cfg);

% Use a one-tap channel while keeping the Doppler condition from vehB.
sys_cfg.pdb = 0;
sys_cfg.tau = 0;

%% Simulation parameters
Dt = 20;                         % Pilot interval
num_sample_training = 10000;     % Number of training channel samples
num_sample_inference = 1000;     % Number of inference channel samples
set_SNRdB = 0:5:20;              % SNR values used for inference
SNRdB_training = 20;             % SNR value used for training data generation

Nt = 8;                          % Number of transmit antennas
Nr = 8;                          % Number of receive antennas
pilot_group = 10;                % Number of pilot groups used as neural network input
pilot_group_total = 65;          % Total number of pilot groups in one generated sequence
T = (pilot_group_total - 1) * Dt + Nt;  % Total number of time samples

%% File and path configuration
% The script is designed to be placed in the "matlab" folder:
%
% project/
% ├── data/
% ├── matlab/
% │   └── nn_channel_estimation.m
% └── nn/
%     ├── dnn.py
%     ├── cnn.py
%     └── lstm.py

file.matlab_path = fileparts(mfilename('fullpath'));
file.project_path = fileparts(file.matlab_path);
file.nn_path = fullfile(file.project_path, 'nn');

addpath(file.matlab_path);

timestamp = char(string(datetime('now', 'Format', 'yyMMddHHmmss')));
file.data_path = fullfile(file.project_path, 'data', timestamp);

if ~exist(file.data_path, 'dir')
    mkdir(file.data_path);
end

% Use the project virtual environment if it exists. Otherwise, fall back to
% the system Python command. On Windows, the expected virtual environment
% path is project/venv/Scripts/python.exe.
python_exe = fullfile(file.project_path, 'venv', 'Scripts', 'python.exe');
if exist(python_exe, 'file') == 2
    file.python_exe = string(python_exe);
else
    file.python_exe = "python";
    warning("Project virtual environment was not found. Falling back to system Python.");
end

dir_name = @(SNR_dB) strcat("_SNR", num2str(SNR_dB), "dB");
training_dir = @(SNR_dB) fullfile(file.data_path, strcat("training", dir_name(SNR_dB)));
inference_dir = @(SNR_dB) fullfile(file.data_path, strcat("inference", dir_name(SNR_dB)));

%% NMSE result buffers
NMSE_DNN = zeros(num_sample_inference, length(set_SNRdB));
NMSE_CNN = zeros(num_sample_inference, length(set_SNRdB));
NMSE_LSTM = zeros(num_sample_inference, length(set_SNRdB));
NMSE_linear = zeros(num_sample_inference, length(set_SNRdB));

%% Training channel generation
% h_training has size [Nr, Nt, T, num_sample_training].
h_training = zeros(Nr, Nt, T, num_sample_training);

for sample = 1:num_sample_training
    t_sample = tic;

    [cir, ~] = time_varying_channel_generation_MIMO(sys_cfg, Nr, Nt, T, 0);
    h_training(:, :, :, sample) = squeeze(cir(:, :, 1, :));

    elapsed_time = toc(t_sample);
    if mod(sample, 10) == 0
        remaining_time = elapsed_time * (num_sample_training - sample);
        fprintf("Training channel sample %d done. Estimated remaining time: %.3f seconds.\n", ...
            sample, remaining_time);
    end
end

%% Training data generation at the selected training SNR
SNRdB = SNRdB_training;
SNR = 10^(SNRdB / 10);

D_dir_training = training_dir(SNRdB);
if ~exist(D_dir_training, 'dir')
    mkdir(D_dir_training);
    fprintf("Directory created: %s\n", D_dir_training);
else
    fprintf("Directory already exists: %s\n", D_dir_training);
end

file.fname_input_data = fullfile(D_dir_training, "input_data.csv");
file.fname_output_data = fullfile(D_dir_training, "output_data.csv");

for tx_i = 1:Nt
    file.(sprintf('fname_input_data_%d', tx_i)) = fullfile(D_dir_training, sprintf('input_data_LSTM_%d.csv', tx_i));
    file.(sprintf('fname_output_data_%d', tx_i)) = fullfile(D_dir_training, sprintf('output_data_LSTM_%d.csv', tx_i));
    file.(sprintf('fname_predicted_data_lstm_%d', tx_i)) = fullfile(D_dir_training, sprintf('predicted_data_lstm_%d.csv', tx_i));
end

file.fname_predicted_data_dnn = fullfile(D_dir_training, "predicted_data_dnn.csv");
file.fname_predicted_data_cnn = fullfile(D_dir_training, "predicted_data_cnn.csv");

% Add complex Gaussian noise to the clean channel data.
noise = (randn(size(h_training)) + 1i * randn(size(h_training))) ./ sqrt(2);
h_estimated = h_training + (1 / sqrt(SNR)) * noise;

%% Generate neural network training input data
total_window = pilot_group_total - (pilot_group - 1);
total_rows = num_sample_training * total_window;

input_rows = cell(total_rows, 1);
lstm_input_rows = cell(Nt, total_rows);

row_idx = 0;
for sample = 1:num_sample_training
    for window_i = 1:total_window
        row_idx = row_idx + 1;

        h_input_tmp = zeros(Nr, Nt * pilot_group);
        h_input_tmp_LSTM = zeros(Nr, pilot_group, Nt);

        for pg_i = 1:pilot_group
            start_i = (pg_i - 1) * Dt + (window_i - 1) * Dt;

            for tx_i = 1:Nt
                stack_i = (pg_i - 1) * Nt;
                h_input_tmp(:, tx_i + stack_i) = h_estimated(:, tx_i, tx_i + start_i, sample);
                h_input_tmp_LSTM(:, pg_i, tx_i) = h_estimated(:, tx_i, tx_i + start_i, sample);
            end
        end

        input_rows{row_idx} = conv_data_complex2real(h_input_tmp(:).');

        for tx_i = 1:Nt
            tmp = h_input_tmp_LSTM(:, :, tx_i);
            lstm_input_rows{tx_i, row_idx} = conv_data_complex2real(tmp(:).');
        end
    end
end

input_data = vertcat(input_rows{:});
input_data_LSTM = cell(1, Nt);

for tx_i = 1:Nt
    input_data_LSTM{tx_i} = vertcat(lstm_input_rows{tx_i, :});
end

writematrix(input_data, file.fname_input_data);

for tx_i = 1:Nt
    key = sprintf('fname_input_data_%d', tx_i);
    writematrix(input_data_LSTM{tx_i}, file.(key));
end

%% Generate neural network training output data
output_rows = cell(total_rows, 1);
lstm_output_rows = cell(Nt, total_rows);

row_idx = 0;
for sample = 1:num_sample_training
    for window_i = 1:total_window
        row_idx = row_idx + 1;

        data_t = Dt * (window_i - 1) + Dt * (pilot_group - 2) + Nt;
        h_output_tmp = h_estimated(:, :, data_t + 1:data_t + (Dt - Nt), sample);

        for tx_i = 1:Nt
            h_output_LSTM_tmp = h_estimated(:, tx_i, data_t + 1:data_t + (Dt - Nt), sample);
            lstm_output_rows{tx_i, row_idx} = conv_data_complex2real(h_output_LSTM_tmp(:).');
        end

        output_rows{row_idx} = conv_data_complex2real(h_output_tmp(:).');
    end
end

output_data = vertcat(output_rows{:});
output_data_LSTM = cell(1, Nt);

for tx_i = 1:Nt
    output_data_LSTM{tx_i} = vertcat(lstm_output_rows{tx_i, :});
end

writematrix(output_data, file.fname_output_data);

for tx_i = 1:Nt
    key = sprintf('fname_output_data_%d', tx_i);
    writematrix(output_data_LSTM{tx_i}, file.(key));
end

%% Train Python neural network models
% DNN training
command_in = buildPythonCommand(file.python_exe, fullfile(file.nn_path, 'dnn.py'), ...
    [D_dir_training, "train", string(pilot_group), string(Nt), string(Nr), string(Dt)]);
runSystemCommand(command_in);
waitForFile(file.fname_predicted_data_dnn, 3600);

% CNN training
command_in = buildPythonCommand(file.python_exe, fullfile(file.nn_path, 'cnn.py'), ...
    [D_dir_training, "train", string(pilot_group), string(Nt), string(Nr), string(Dt)]);
runSystemCommand(command_in);
waitForFile(file.fname_predicted_data_cnn, 3600);

% LSTM training. A separate LSTM model is trained for each transmit antenna.
for tx_i = 1:Nt
    command_in = buildPythonCommand(file.python_exe, fullfile(file.nn_path, 'lstm.py'), ...
        [D_dir_training, "train", string(pilot_group), string(tx_i), string(Nr)]);
    runSystemCommand(command_in);

    filename = file.(sprintf('fname_predicted_data_lstm_%d', tx_i));
    waitForFile(filename, 3600);
end

%% Inference channel generation
h_inference = zeros(Nr, Nt, T, num_sample_inference);

for sample = 1:num_sample_inference
    t_sample = tic;

    [cir, ~] = time_varying_channel_generation_MIMO(sys_cfg, Nr, Nt, T, 0);
    h_inference(:, :, :, sample) = squeeze(cir(:, :, 1, :));

    elapsed_time = toc(t_sample);
    if mod(sample, 10) == 0
        remaining_time = elapsed_time * (num_sample_inference - sample);
        fprintf("Inference channel sample %d done. Estimated remaining time: %.3f seconds.\n", ...
            sample, remaining_time);
    end
end

%% Inference data generation and NMSE evaluation
for isnr = 1:length(set_SNRdB)
    SNRdB = set_SNRdB(isnr);
    SNR = 10^(SNRdB / 10);

    noise = (randn(size(h_inference)) + 1i * randn(size(h_inference))) ./ sqrt(2);
    h_inference_estimated = h_inference + (1 / sqrt(SNR)) * noise;

    D_dir_inference = inference_dir(SNRdB);

    if ~exist(D_dir_inference, 'dir')
        mkdir(D_dir_inference);
        fprintf("Directory created: %s\n", D_dir_inference);
    else
        fprintf("Directory already exists: %s\n", D_dir_inference);
    end

    file.fname_input_data = fullfile(D_dir_inference, "input_data.csv");

    for tx_i = 1:Nt
        file.(sprintf('fname_input_data_%d', tx_i)) = fullfile(D_dir_inference, sprintf('input_data_LSTM_%d.csv', tx_i));
        file.(sprintf('fname_predicted_data_lstm_%d', tx_i)) = fullfile(D_dir_inference, sprintf('predicted_data_lstm_%d.csv', tx_i));
    end

    file.fname_predicted_data_dnn = fullfile(D_dir_inference, "predicted_data_dnn.csv");
    file.fname_predicted_data_cnn = fullfile(D_dir_inference, "predicted_data_cnn.csv");

    %% Generate inference input data and reference channel data
    total_window = pilot_group_total - (pilot_group - 1);
    total_rows = num_sample_inference * total_window;

    input_rows_infer = cell(total_rows, 1);
    lstm_input_rows_infer = cell(Nt, total_rows);

    h_linear = zeros(Nr, Nt, Dt - Nt, total_window * num_sample_inference);
    h_correct_tmp = zeros(Nr, Nt, Dt - Nt, total_window * num_sample_inference);

    row_idx = 0;
    for sample = 1:num_sample_inference
        for window_i = 1:total_window
            row_idx = row_idx + 1;

            h_inference_input_tmp = zeros(Nr, Nt * pilot_group);
            h_inference_input_LSTM_tmp = zeros(Nr, pilot_group, Nt);

            for pg_i = 1:pilot_group
                start_i = (pg_i - 1) * Dt + (window_i - 1) * Dt;

                for tx_i = 1:Nt
                    stack_i = (pg_i - 1) * Nt;
                    h_inference_input_tmp(:, tx_i + stack_i) = h_inference_estimated(:, tx_i, tx_i + start_i, sample);
                    h_inference_input_LSTM_tmp(:, pg_i, tx_i) = h_inference_estimated(:, tx_i, tx_i + start_i, sample);
                end
            end

            % Linear interpolation baseline.
            for nt_i = 1:Nt
                index_for_value = nt_i + Nt * (0:pilot_group - 1);
                index_value = h_inference_input_tmp(:, index_for_value);

                pilot_index = nt_i + Dt * (0:pilot_group - 1);
                interpolation_index = Dt * (pilot_group - 2) + Nt + 1 : ...
                                      Dt * (pilot_group - 2) + Nt + Dt - Nt;

                h_linear(:, nt_i, :, window_i + (sample - 1) * total_window) = ...
                    interp1(pilot_index, index_value.', interpolation_index, 'linear').';
            end

            input_rows_infer{row_idx} = conv_data_complex2real(h_inference_input_tmp(:).');

            for tx_i = 1:Nt
                tmp = h_inference_input_LSTM_tmp(:, :, tx_i);
                lstm_input_rows_infer{tx_i, row_idx} = conv_data_complex2real(tmp(:).');
            end

            data_start_t = Dt * (window_i - 1) + Dt * (pilot_group - 2) + Nt;
            h_correct_tmp(:, :, :, window_i + (sample - 1) * total_window) = ...
                h_inference(:, :, data_start_t + 1:data_start_t + (Dt - Nt), sample);
        end
    end

    input_data_infer = vertcat(input_rows_infer{:});
    input_data_LSTM_infer = cell(1, Nt);

    for tx_i = 1:Nt
        input_data_LSTM_infer{tx_i} = vertcat(lstm_input_rows_infer{tx_i, :});
    end

    writematrix(input_data_infer, file.fname_input_data);

    for tx_i = 1:Nt
        key = sprintf('fname_input_data_%d', tx_i);
        writematrix(input_data_LSTM_infer{tx_i}, file.(key));
    end

    %% Run Python inference
    file.fname_dnn_model = fullfile(D_dir_training, "dnn_model.h5");
    file.fname_cnn_model = fullfile(D_dir_training, "cnn_model.h5");

    % DNN inference
    command_in = buildPythonCommand(file.python_exe, fullfile(file.nn_path, 'dnn.py'), ...
        [D_dir_inference, "infer", string(pilot_group), string(Nt), string(Nr), string(Dt), file.fname_dnn_model]);
    runSystemCommand(command_in);
    waitForFile(file.fname_predicted_data_dnn, 3600);

    % CNN inference
    command_in = buildPythonCommand(file.python_exe, fullfile(file.nn_path, 'cnn.py'), ...
        [D_dir_inference, "infer", string(pilot_group), string(Nt), string(Nr), string(Dt), file.fname_cnn_model]);
    runSystemCommand(command_in);
    waitForFile(file.fname_predicted_data_cnn, 3600);

    % LSTM inference for each transmit antenna.
    for tx_i = 1:Nt
        model_name = sprintf("lstm_model_%d.h5", tx_i);
        file.(sprintf('fname_lstm_model_%d', tx_i)) = fullfile(D_dir_training, model_name);

        command_in = buildPythonCommand(file.python_exe, fullfile(file.nn_path, 'lstm.py'), ...
            [D_dir_inference, "infer", string(pilot_group), string(tx_i), string(Nr), ...
             file.(sprintf('fname_lstm_model_%d', tx_i))]);
        runSystemCommand(command_in);

        filename = file.(sprintf('fname_predicted_data_lstm_%d', tx_i));
        waitForFile(filename, 3600);
    end

    %% Reconstruct complex-valued prediction results
    h_inference_predicted_lstm = zeros(Nr, Nt, Dt - Nt, total_window * num_sample_inference);
    h_inference_predicted_dnn = zeros(Nr, Nt, Dt - Nt, total_window * num_sample_inference);
    h_inference_predicted_cnn = zeros(Nr, Nt, Dt - Nt, total_window * num_sample_inference);

    for tx_i = 1:Nt
        fname = sprintf('fname_predicted_data_lstm_%d', tx_i);
        predicted_lstm_real = readmatrix(file.(fname));
        predicted_lstm_complex = conv_data_real2complex(predicted_lstm_real);

        tmp = reshape(predicted_lstm_complex, [total_window * num_sample_inference, Nr, Dt - Nt]);
        tmp = permute(tmp, [2, 3, 1]);

        h_inference_predicted_lstm(:, tx_i, :, :) = ...
            reshape(tmp, [Nr, 1, Dt - Nt, total_window * num_sample_inference]);
    end

    predicted_dnn_real = readmatrix(file.fname_predicted_data_dnn);
    predicted_cnn_real = readmatrix(file.fname_predicted_data_cnn);

    predicted_dnn_complex = conv_data_real2complex(predicted_dnn_real);
    predicted_cnn_complex = conv_data_real2complex(predicted_cnn_real);

    for idx = 1:total_window * num_sample_inference
        h_inference_predicted_dnn(:, :, :, idx) = reshape(predicted_dnn_complex(idx, :), [Nr, Nt, Dt - Nt]);
        h_inference_predicted_cnn(:, :, :, idx) = reshape(predicted_cnn_complex(idx, :), [Nr, Nt, Dt - Nt]);
    end

    %% NMSE calculation
    for sample = 1:num_sample_inference
        for window_i = 1:total_window
            idx = window_i + (sample - 1) * total_window;

            for d_i = 1:Dt - Nt
                reference_channel = h_correct_tmp(:, :, d_i, idx);
                denominator = norm(reference_channel, 'fro')^2;

                NMSE_DNN(sample, isnr) = NMSE_DNN(sample, isnr) + ...
                    norm(reference_channel - h_inference_predicted_dnn(:, :, d_i, idx), 'fro')^2 / denominator;

                NMSE_CNN(sample, isnr) = NMSE_CNN(sample, isnr) + ...
                    norm(reference_channel - h_inference_predicted_cnn(:, :, d_i, idx), 'fro')^2 / denominator;

                NMSE_LSTM(sample, isnr) = NMSE_LSTM(sample, isnr) + ...
                    norm(reference_channel - h_inference_predicted_lstm(:, :, d_i, idx), 'fro')^2 / denominator;

                NMSE_linear(sample, isnr) = NMSE_linear(sample, isnr) + ...
                    norm(reference_channel - h_linear(:, :, d_i, idx), 'fro')^2 / denominator;
            end
        end
    end
end

%% Plot NMSE performance
figure;
semilogy(set_SNRdB, sum(NMSE_DNN, 1) ./ (num_sample_inference * total_window * (Dt - Nt)), 'ro-');
hold on;
semilogy(set_SNRdB, sum(NMSE_CNN, 1) ./ (num_sample_inference * total_window * (Dt - Nt)), 'mx-');
semilogy(set_SNRdB, sum(NMSE_LSTM, 1) ./ (num_sample_inference * total_window * (Dt - Nt)), 'g^-');
semilogy(set_SNRdB, sum(NMSE_linear, 1) ./ (num_sample_inference * total_window * (Dt - Nt)), 'bd-');
grid on;

legend({'DNN', 'CNN', 'LSTM', 'Linear'}, 'Location', 'Northeast');

title_str = sprintf('[N_T=%d, N_R=%d, D_t=%d, P_g=%d, T=%d, Training SNR=%d dB, Channel=%s]', ...
    Nt, Nr, Dt, pilot_group, T, SNRdB_training, sys_cfg.channel_model);
title(title_str);
xlabel('SNR [dB]');
ylabel('NMSE');

%% Local helper functions
function command = buildPythonCommand(python_exe, script_path, args)
%BUILDPYTHONCOMMAND Build a safe command string for MATLAB system calls.
%
%   Paths are quoted to handle spaces in folder names.

    quote = @(x) strcat('"', string(x), '"');
    command_parts = [quote(python_exe), quote(script_path)];

    for idx = 1:numel(args)
        command_parts(end + 1) = quote(args(idx)); %#ok<AGROW>
    end

    command = strjoin(command_parts, " ");
end

function runSystemCommand(command)
%RUNSYSTEMCOMMAND Run a system command and stop if the command fails.

    fprintf("Running command:\n%s\n", command);
    [status, cmdout] = system(command);

    if status ~= 0
        error("Python command failed with status %d.\nCommand output:\n%s", status, cmdout);
    end
end

function waitForFile(filename, timeout_sec)
%WAITFORFILE Wait until a generated file exists.
%
%   This prevents MATLAB from continuing before the Python script finishes
%   writing its output file.

    start_time = tic;

    while exist(filename, 'file') == 0
        pause(1);

        if toc(start_time) > timeout_sec
            error("Timeout while waiting for file: %s", filename);
        end
    end
end
