function data = conv_data_complex2real(data)
%CONV_DATA_COMPLEX2REAL Convert complex-valued data into real-valued data.
%
%   data = CONV_DATA_COMPLEX2REAL(data) converts an input matrix of size
%   [num_sample, data_dim] into a real-valued matrix of size
%   [num_sample, 2*data_dim].
%
%   For each row vector v, the output row is defined as:
%       [real(v), imag(v)]
%
%   This format is used because the neural network models operate on
%   real-valued input and output vectors.

data = [real(data), imag(data)];

end
