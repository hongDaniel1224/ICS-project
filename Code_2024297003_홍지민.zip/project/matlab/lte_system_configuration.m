function obj = lte_system_configuration(obj)
%LTE_SYSTEM_CONFIGURATION Configure LTE bandwidth and channel parameters.
%
%   obj = LTE_SYSTEM_CONFIGURATION(obj) fills in system parameters such as
%   FFT size, number of subcarriers, sampling rate, path delays, average
%   path gains, and user speed according to the selected bandwidth and
%   channel model.
%
%   Required input fields:
%       obj.bandwidth       - LTE bandwidth string, e.g., '10MHz'
%       obj.channel_model   - channel model string, e.g., 'vehB'
%
%   Optional input field:
%       obj.user_speed      - user speed in km/h for EPA, EVA, and ETU

% Reference: 3GPP TS 36.104

%% Bandwidth configuration
obj.subcarrier_spacing = 15e3;

switch obj.bandwidth
    case '1.4MHz'
        obj.fft_size = 128;
        obj.num_subcarrier = 72;
        obj.sample_rate = 1.92e6;

    case '3MHz'
        obj.fft_size = 256;
        obj.num_subcarrier = 180;
        obj.sample_rate = 3.84e6;

    case '5MHz'
        obj.fft_size = 512;
        obj.num_subcarrier = 300;
        obj.sample_rate = 7.68e6;

    case '10MHz'
        obj.fft_size = 1024;
        obj.num_subcarrier = 600;
        obj.sample_rate = 15.36e6;

    case '15MHz'
        obj.fft_size = 1536;
        obj.num_subcarrier = 900;
        obj.sample_rate = 23.04e6;

    case '20MHz'
        obj.fft_size = 2048;
        obj.num_subcarrier = 1200;
        obj.sample_rate = 30.72e6;

    otherwise
        error('Invalid bandwidth: %s', obj.bandwidth);
end

%% Channel model configuration
switch obj.channel_model
    case "office"
        obj.tau = [0 50 110 170 290 310] * 1e-9;
        obj.pdb = [0 -4 -20 -18 -26 -32];
        obj.user_speed = 0 * 1e3 / 3600;

    case "pedA"  % 3GPP TR 25.996 pedestrian A channel
        obj.tau = [0 110 190 410] * 1e-9;
        obj.pdb = [0 -9.7 -19.2 -22.8];
        obj.user_speed = 3 * 1e3 / 3600;

    case "vehA"
        obj.tau = [0 310 710 1090 1730 2510] * 1e-9;
        obj.pdb = [0 -1 -9 -10 -15 -20];
        obj.user_speed = 30 * 1e3 / 3600;

    case "pedB"
        obj.tau = [0 200 800 1200 2300 3700] * 1e-9;
        obj.pdb = [0 -0.9 -4.9 -8.0 -7.8 -23.9];
        obj.user_speed = 10 * 1e3 / 3600;

    case "vehB"
        obj.tau = [0 300 8900 12900 17100 20000] * 1e-9;
        obj.pdb = [-2.5 0 -12.8 -10.0 -25.2 -16.0];
        obj.user_speed = 120 * 1e3 / 3600;

    case "EPA"  % 3GPP TS 36.104 Annex B.2 / TS 36.101 Annex B.2
        obj.tau = [0 30 70 90 110 190 410] * 1e-9;
        obj.pdb = [0 -1 -2 -3 -8 -17.2 -20.8];
        if ~isfield(obj, 'user_speed')
            obj.user_speed = 3;
        end
        obj.user_speed = obj.user_speed * 1e3 / 3600;

    case "EVA"
        obj.tau = [0 30 150 310 370 710 1090 1730 2510] * 1e-9;
        obj.pdb = [0 -1.5 -1.4 -3.6 -0.6 -9.1 -7 -12 -16.9];
        if ~isfield(obj, 'user_speed')
            obj.user_speed = 30;
        end
        obj.user_speed = obj.user_speed * 1e3 / 3600;

    case "ETU"
        obj.tau = [0 50 120 200 230 500 1600 2300 5000] * 1e-9;
        obj.pdb = [-1 -1 -1 0 0 0 -3 -5 -7];
        if ~isfield(obj, 'user_speed')
            obj.user_speed = 120;
        end
        obj.user_speed = obj.user_speed * 1e3 / 3600;

    otherwise
        error('Invalid channel model: %s', obj.channel_model);
end

end
