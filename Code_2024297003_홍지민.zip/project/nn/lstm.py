"""LSTM separation-based channel estimation script.

This script trains or runs inference for one transmit antenna index at a
time. The MATLAB main script calls this file repeatedly from tx_i = 1 to Nt.

Usage:
    Training:
        python nn/lstm.py <data_dir> train <pilot_group> <tx_i> <Nr>

    Inference:
        python nn/lstm.py <data_dir> infer <pilot_group> <tx_i> <Nr> <model_path>
"""

import math
import os
import sys

import numpy as np
import pandas as pd
from tensorflow.keras import layers, models
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.optimizers import Adam


def print_usage() -> None:
    """Print the command-line usage guide."""
    print(
        "Usage:\n"
        "  Train : python nn/lstm.py <data_dir> train <pilot_group> <tx_i> <Nr>\n"
        "  Infer : python nn/lstm.py <data_dir> infer <pilot_group> <tx_i> <Nr> <model_path>"
    )


def build_lstm_model(input_shape: tuple[int, int], output_dim: int, node: int) -> models.Sequential:
    """Build an LSTM model for one transmit antenna."""
    model = models.Sequential()
    model.add(layers.LSTM(node, input_shape=input_shape, return_sequences=False))
    model.add(layers.Dense(output_dim, activation="linear"))
    return model


def main() -> None:
    """Run LSTM separation training or inference."""
    if len(sys.argv) < 6:
        print_usage()
        sys.exit(1)

    data_dir = sys.argv[1]
    mode = sys.argv[2].lower()

    if mode not in {"train", "infer"}:
        print("Error: mode must be either 'train' or 'infer'.")
        print_usage()
        sys.exit(1)

    if mode == "infer" and len(sys.argv) < 7:
        print("Error: model_path is required in inference mode.")
        print_usage()
        sys.exit(1)

    pilot_group = int(sys.argv[3])
    tx_i = int(sys.argv[4])
    nr = int(sys.argv[5])

    input_path = os.path.join(data_dir, f"input_data_LSTM_{tx_i}.csv")
    output_pred_path = os.path.join(data_dir, f"predicted_data_lstm_{tx_i}.csv")
    checkpoint_path = os.path.join(data_dir, f"lstm_model_{tx_i}.h5")

    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Input data file does not exist: {input_path}")

    # Load the LSTM input for the selected transmit antenna.
    # The first half contains real parts and the second half contains
    # imaginary parts. Each part is reshaped into [sample, pilot_group, Nr].
    x_raw = pd.read_csv(input_path, header=None).values

    real_part = x_raw[:, : pilot_group * nr].reshape(-1, pilot_group, nr)
    imag_part = x_raw[:, pilot_group * nr :].reshape(-1, pilot_group, nr)
    x_data = np.concatenate([real_part, imag_part], axis=-1)

    if mode == "train":
        output_path = os.path.join(data_dir, f"output_data_LSTM_{tx_i}.csv")

        if not os.path.exists(output_path):
            raise FileNotFoundError(f"Output data file does not exist: {output_path}")

        y_data = pd.read_csv(output_path, header=None).values
        output_dim = y_data.shape[1]

        # Choose the LSTM hidden size as the next power of two.
        hidden_node = 1 << math.ceil(math.log2(2 * nr * pilot_group))
        print(f"LSTM hidden nodes for tx_i={tx_i}: {hidden_node}")

        model = build_lstm_model((pilot_group, nr * 2), output_dim, hidden_node)
        model.compile(optimizer=Adam(learning_rate=1e-5), loss="mse", metrics=["mse"])

        early_stop = EarlyStopping(
            monitor="val_mse",
            patience=10,
            restore_best_weights=True,
            verbose=1,
        )
        checkpoint_cb = ModelCheckpoint(
            checkpoint_path,
            monitor="val_mse",
            save_best_only=True,
            verbose=1,
        )

        model.fit(
            x_data,
            y_data,
            epochs=100,
            batch_size=64,
            validation_split=0.1,
            callbacks=[early_stop, checkpoint_cb],
            verbose=1,
        )

        y_pred = model.predict(x_data)
        pd.DataFrame(y_pred).to_csv(output_pred_path, index=False, header=False)
        print(f"Training prediction results saved to: {output_pred_path}")

    else:
        model_path = sys.argv[6]

        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model file does not exist: {model_path}")

        model = models.load_model(model_path, compile=False)
        y_pred = model.predict(x_data)
        pd.DataFrame(y_pred).to_csv(output_pred_path, index=False, header=False)
        print(f"Inference prediction results saved to: {output_pred_path}")


if __name__ == "__main__":
    main()
